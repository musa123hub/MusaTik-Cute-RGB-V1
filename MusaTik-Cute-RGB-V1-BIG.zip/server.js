const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/check", (req, res) => {
  const { url } = req.body || {};

  if (!url) {
    return res.status(400).json({ success: false, message: "Paste a TikTok link first." });
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return res.status(400).json({ success: false, message: "Invalid URL." });
  }

  const hosts = ["tiktok.com", "www.tiktok.com", "m.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"];

  if (!hosts.includes(parsed.hostname)) {
    return res.status(400).json({ success: false, message: "Please enter a valid TikTok URL." });
  }

  res.json({
    success: true,
    message: "TikTok link detected. Use only content you own or have permission to save."
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`MusaTik Cute RGB V1: http://localhost:${PORT}`);
});
