const root = document.documentElement;
const urlInput = document.querySelector("#urlInput");
const pasteBtn = document.querySelector("#pasteBtn");
const downloadBtn = document.querySelector("#downloadBtn");
const btnText = document.querySelector("#btnText");
const loader = document.querySelector("#loader");
const message = document.querySelector("#message");
const toggle = document.querySelector("#rgbToggle");

const hue = document.querySelector("#hue");
const speed = document.querySelector("#speed");
const glow = document.querySelector("#glow");

const hueValue = document.querySelector("#hueValue");
const speedValue = document.querySelector("#speedValue");
const glowValue = document.querySelector("#glowValue");

let rgbOn = true;

function setRGB() {
  root.style.setProperty("--hue", hue.value);
  root.style.setProperty("--speed", `${13 - Number(speed.value)}s`);
  root.style.setProperty("--glow", Number(glow.value) / 100);
  hueValue.textContent = `${hue.value}°`;
  speedValue.textContent = speed.value;
  glowValue.textContent = `${glow.value}%`;
}

[hue, speed, glow].forEach(el => el.addEventListener("input", setRGB));

document.querySelectorAll(".swatches button").forEach(btn => {
  btn.addEventListener("click", () => {
    hue.value = btn.dataset.hue;
    setRGB();
  });
});

toggle.addEventListener("click", () => {
  rgbOn = !rgbOn;
  toggle.textContent = rgbOn ? "ON" : "OFF";
  toggle.classList.toggle("active", rgbOn);
  root.style.setProperty("--glow", rgbOn ? Number(glow.value) / 100 : 0);
});

pasteBtn.addEventListener("click", async () => {
  try {
    urlInput.value = await navigator.clipboard.readText();
    urlInput.focus();
  } catch {
    message.classList.remove("hidden");
    message.textContent = "Clipboard permission was not available. Paste manually.";
  }
});

downloadBtn.addEventListener("click", async () => {
  const url = urlInput.value.trim();
  message.classList.add("hidden");

  if (!url) {
    message.textContent = "💗 Please paste a TikTok link first.";
    message.classList.remove("hidden");
    return;
  }

  downloadBtn.disabled = true;
  btnText.classList.add("hidden");
  loader.classList.remove("hidden");

  try {
    const response = await fetch("/api/check", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({url})
    });

    const data = await response.json();

    if (!response.ok || !data.success) throw new Error(data.message || "Unable to check link.");

    message.textContent = "✨ Link detected! This V1 does not bypass TikTok protections or scrape arbitrary third-party videos. Connect an authorized content/API source where permitted.";
    message.classList.remove("hidden");
  } catch (err) {
    message.textContent = `❌ ${err.message}`;
    message.classList.remove("hidden");
  } finally {
    downloadBtn.disabled = false;
    btnText.classList.remove("hidden");
    loader.classList.add("hidden");
  }
});

setRGB();
